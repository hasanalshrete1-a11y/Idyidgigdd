package com.example.ads

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.browser.customtabs.CustomTabsIntent

/**
 * AdManager helper class for Monetag Ad Integration.
 * Uses Direct Link placeholders and launches CustomTabsIntent securely.
 */
object AdManager {

    /**
     * Monetag Direct Link URL Placeholder.
     * Developers can replace this placeholder with their active Monetag Direct Link campaign URL.
     */
    const val DIRECT_LINK_URL: String = "https://al5sm8r9k.com/monetag_direct_link_placeholder"

    /**
     * Shows the Monetag direct ad link using Chrome Custom Tabs,
     * falling back to standard ACTION_VIEW if necessary.
     * Invokes [onAdClosed] to unlock premium educational features.
     *
     * @param context Android context
     * @param adUrl The Monetag direct ad link (defaults to [DIRECT_LINK_URL])
     * @param onAdClosed Callback invoked once the ad is completed/returned to grant access
     */
    fun showMonetagAd(
        context: Context,
        adUrl: String = DIRECT_LINK_URL,
        onAdClosed: () -> Unit
    ) {
        try {
            val uri = Uri.parse(if (adUrl.isNotBlank()) adUrl else DIRECT_LINK_URL)
            val customTabsIntent = CustomTabsIntent.Builder()
                .setShowTitle(true)
                .setUrlBarHidingEnabled(true)
                .build()

            // If context is not an activity, add FLAG_ACTIVITY_NEW_TASK
            if (context !is Activity) {
                customTabsIntent.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            customTabsIntent.launchUrl(context, uri)

            // Trigger the unlock callback to reward the user
            onAdClosed()
        } catch (e: ActivityNotFoundException) {
            // Fallback to standard ACTION_VIEW intent
            try {
                val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse(adUrl)).apply {
                    if (context !is Activity) {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                }
                context.startActivity(fallbackIntent)
                onAdClosed()
            } catch (fallbackEx: Exception) {
                Toast.makeText(context, "Unable to open ad link: ${fallbackEx.message}", Toast.LENGTH_SHORT).show()
                // Still unlock feature gracefully
                onAdClosed()
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Ad completed. Content unlocked!", Toast.LENGTH_SHORT).show()
            onAdClosed()
        }
    }
}
