package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.local.PreferencesManager
import com.example.data.repository.EducationalRepository
import com.example.data.repository.FinanceRepository
import com.example.data.repository.HabitRepository
import com.example.data.repository.SecurityRepository
import com.example.notification.NotificationHelper
import com.example.ui.navigation.AppNavigation
import com.example.ui.screens.dashboard.DashboardViewModel
import com.example.ui.screens.library.LibraryViewModel
import com.example.ui.screens.lock.LockScreen
import com.example.ui.screens.onboarding.OnboardingScreen
import com.example.ui.screens.settings.SettingsViewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.util.ProvideAppLocale
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize local database & repositories
        val database = AppDatabase.getInstance(applicationContext)
        val preferencesManager = PreferencesManager(applicationContext)

        val financeRepository = FinanceRepository(database.dailyLogDao())
        val habitRepository = HabitRepository(database.habitDao())
        val educationalRepository = EducationalRepository(preferencesManager)
        val securityRepository = SecurityRepository(preferencesManager)

        // Ensure offline reminder notification channel is registered
        NotificationHelper.createNotificationChannel(applicationContext)

        setContent {
            val appLanguage by preferencesManager.appLanguageFlow.collectAsStateWithLifecycle(initialValue = "en")
            val isOnboardingCompleted by preferencesManager.isOnboardingCompletedFlow.collectAsStateWithLifecycle(initialValue = false)
            val scope = rememberCoroutineScope()

            ProvideAppLocale(languageCode = appLanguage) {
                MyApplicationTheme {
                    val isPinEnabled by securityRepository.isPinEnabled.collectAsStateWithLifecycle(initialValue = false)
                    val isBiometricEnabled by securityRepository.isBiometricEnabled.collectAsStateWithLifecycle(initialValue = false)

                    var isUnlocked by rememberSaveable { mutableStateOf(false) }

                    val dashboardViewModel = remember { DashboardViewModel(financeRepository, habitRepository) }
                    val libraryViewModel = remember { LibraryViewModel(educationalRepository) }
                    val settingsViewModel = remember { SettingsViewModel(securityRepository, financeRepository, habitRepository, preferencesManager) }

                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        Crossfade(
                            targetState = when {
                                !isOnboardingCompleted -> ScreenState.Onboarding
                                isPinEnabled && !isUnlocked -> ScreenState.Locked
                                else -> ScreenState.Main
                            },
                            animationSpec = tween(300),
                            label = "MainScreenStateTransition"
                        ) { state ->
                            when (state) {
                                ScreenState.Onboarding -> {
                                    OnboardingScreen(
                                        currentLanguageCode = appLanguage,
                                        onLanguageSelected = { langCode ->
                                            scope.launch { preferencesManager.setAppLanguage(langCode) }
                                        },
                                        onGetStartedClick = {
                                            scope.launch { preferencesManager.setOnboardingCompleted(true) }
                                        }
                                    )
                                }
                                ScreenState.Locked -> {
                                    LockScreen(
                                        securityRepository = securityRepository,
                                        isBiometricAvailable = isBiometricEnabled,
                                        onUnlockSuccessful = { isUnlocked = true }
                                    )
                                }
                                ScreenState.Main -> {
                                    AppNavigation(
                                        dashboardViewModel = dashboardViewModel,
                                        libraryViewModel = libraryViewModel,
                                        settingsViewModel = settingsViewModel,
                                        educationalRepository = educationalRepository
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private enum class ScreenState {
    Onboarding,
    Locked,
    Main
}

/**
 * Kept for unit & screenshot testing compatibility.
 */
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MyApplicationTheme { Greeting("Android") }
}
