package com.example.ui.screens.library

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ads.AdManager
import com.example.data.model.BookSummary
import com.example.ui.theme.ClayAmberBg
import com.example.ui.theme.ClayBadge
import com.example.ui.theme.ClayButton
import com.example.ui.theme.ClayCard
import com.example.ui.theme.ClayMintBg
import com.example.ui.theme.ClaySkyBg
import com.example.ui.theme.GoldRating
import com.example.ui.theme.SuccessGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: LibraryViewModel,
    onNavigateToReader: (bookId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val booksList by viewModel.booksList.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.library_title),
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black)
                        )
                        Text(
                            text = stringResource(R.string.library_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Search Input
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = viewModel::onSearchQueryChange,
                    label = { Text(stringResource(R.string.library_search_hint)) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = stringResource(R.string.library_search_hint))
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_books_input")
                )
            }

            // Categories horizontal scroll chips
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    viewModel.categories.forEach { cat ->
                        val isSelected = selectedCategory == cat
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.selectCategory(cat) },
                            label = { Text(getCategoryLabel(cat)) },
                            shape = RoundedCornerShape(16.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag("category_chip_$cat")
                        )
                    }
                }
            }

            // Educational Catalog list
            items(booksList, key = { it.book.id }) { item ->
                BookSummaryCard(
                    book = item.book,
                    isUnlocked = item.isUnlocked,
                    onReadClick = {
                        if (item.isUnlocked) {
                            onNavigateToReader(item.book.id)
                        } else {
                            AdManager.showMonetagAd(context) {
                                viewModel.unlockBook(item.book.id)
                                onNavigateToReader(item.book.id)
                            }
                        }
                    },
                    onChecklistClick = {
                        if (item.isUnlocked) {
                            onNavigateToReader(item.book.id)
                        } else {
                            AdManager.showMonetagAd(context) {
                                viewModel.unlockBook(item.book.id)
                                onNavigateToReader(item.book.id)
                            }
                        }
                    }
                )
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun getCategoryLabel(category: String): String {
    return when (category) {
        "All" -> stringResource(R.string.category_all)
        "Productivity" -> stringResource(R.string.category_productivity)
        "Finance" -> stringResource(R.string.category_finance)
        "Growth" -> stringResource(R.string.category_growth)
        "Health" -> stringResource(R.string.category_health)
        "Freelance" -> stringResource(R.string.category_freelance)
        else -> category
    }
}

@Composable
private fun BookSummaryCard(
    book: BookSummary,
    isUnlocked: Boolean,
    onReadClick: () -> Unit,
    onChecklistClick: () -> Unit
) {
    ClayCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        backgroundColor = MaterialTheme.colorScheme.surface,
        elevation = 5.dp,
        contentPadding = PaddingValues(20.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header Row: Category badge & Lock/Unlocked indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ClayBadge(
                    text = getCategoryLabel(book.category),
                    backgroundColor = ClaySkyBg,
                    contentColor = Color(0xFF0288D1)
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.library_min_read, book.readTimeMinutes),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    if (isUnlocked) {
                        ClayBadge(
                            text = if (book.isFreePreview) stringResource(R.string.library_free_badge) else stringResource(R.string.library_unlocked_badge),
                            backgroundColor = ClayMintBg,
                            contentColor = SuccessGreen,
                            icon = Icons.Default.LockOpen,
                            iconTint = SuccessGreen
                        )
                    } else {
                        ClayBadge(
                            text = stringResource(R.string.library_ad_locked_badge),
                            backgroundColor = ClayAmberBg,
                            contentColor = Color(0xFF78350F),
                            icon = Icons.Default.Lock,
                            iconTint = GoldRating
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Title and Author
            Text(
                text = book.title,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = stringResource(R.string.library_by_author, book.author),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Teaser / Key quote in a tactile container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                    .padding(14.dp)
            ) {
                Text(
                    text = "“${book.teaser}”",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        lineHeight = 20.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action 3D Clay Buttons (Read Summary & Action Checklist)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ClayButton(
                    onClick = onReadClick,
                    text = if (isUnlocked) stringResource(R.string.library_read_button) else stringResource(R.string.library_unlock_button),
                    leadingIcon = if (isUnlocked) Icons.Default.MenuBook else Icons.Default.AutoAwesome,
                    backgroundColor = if (isUnlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                    contentColor = if (isUnlocked) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSecondary,
                    modifier = Modifier
                        .weight(1.3f)
                        .height(48.dp)
                        .testTag("read_summary_${book.id}")
                )

                ClayButton(
                    onClick = onChecklistClick,
                    text = stringResource(R.string.library_checklist_button),
                    leadingIcon = Icons.Default.Checklist,
                    backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("download_checklist_${book.id}")
                )
            }
        }
    }
}
