package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.ClayBadge
import com.example.ui.theme.ClayButton
import com.example.ui.theme.ClayCard
import com.example.ui.theme.ClayMintBg
import com.example.ui.theme.ClaySkyBg
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.GoldRating
import com.example.ui.theme.SuccessGreen
import java.util.Locale

@Composable
fun HourlyRateCard(
    income: Double,
    expense: Double,
    workHours: Double,
    modifier: Modifier = Modifier
) {
    val net = income - expense
    val hourlyRate = if (workHours > 0.0) net / workHours else 0.0

    ClayCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        backgroundColor = ClaySkyBg,
        elevation = 6.dp,
        contentPadding = PaddingValues(20.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .shadow(3.dp, RoundedCornerShape(14.dp))
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0288D1)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = stringResource(R.string.dashboard_hourly_rate_title),
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.dashboard_hourly_rate_title),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFF01579B)
                        )
                        Text(
                            text = stringResource(R.string.dashboard_hourly_rate_formula_hint),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF0277BD)
                        )
                    }
                }

                val leverageText = when {
                    workHours <= 0.0 -> stringResource(R.string.dashboard_hourly_rate_pending)
                    hourlyRate >= 50.0 -> stringResource(R.string.dashboard_hourly_rate_leverage)
                    hourlyRate > 0.0 -> stringResource(R.string.dashboard_hourly_rate_productive)
                    else -> stringResource(R.string.dashboard_hourly_rate_pending)
                }

                ClayBadge(
                    text = leverageText,
                    backgroundColor = Color.White,
                    contentColor = Color(0xFF0288D1)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Display
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = if (workHours > 0.0) {
                        "${if (hourlyRate < 0) "-" else ""}$${String.format(Locale.US, "%.2f", kotlin.math.abs(hourlyRate))}"
                    } else {
                        "$0.00"
                    },
                    style = MaterialTheme.typography.displaySmall.copy(
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.SansSerif
                    ),
                    color = if (hourlyRate >= 0) Color(0xFF01579B) else ExpenseRed
                )
                Text(
                    text = stringResource(R.string.dashboard_hourly_rate_unit),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = Color(0xFF0288D1),
                    modifier = Modifier.padding(bottom = 4.dp, start = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Formula Preview Clay Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White.copy(alpha = 0.85f))
                    .border(1.dp, Color.White, RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(
                    text = if (workHours > 0.0) {
                        stringResource(
                            R.string.dashboard_hourly_rate_formula_calc,
                            "$${String.format(Locale.US, "%.2f", income)}",
                            "$${String.format(Locale.US, "%.2f", expense)}",
                            String.format(Locale.US, "%.1f", workHours),
                            "$${String.format(Locale.US, "%.2f", hourlyRate)}"
                        )
                    } else {
                        stringResource(R.string.dashboard_hourly_rate_empty_tip)
                    },
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.5.sp
                    ),
                    color = Color(0xFF0D47A1)
                )
            }
        }
    }
}

@Composable
fun DailyLogInputSection(
    incomeInput: String,
    onIncomeChange: (String) -> Unit,
    expenseInput: String,
    onExpenseChange: (String) -> Unit,
    hoursInput: String,
    onHoursChange: (String) -> Unit,
    notesInput: String,
    onNotesChange: (String) -> Unit,
    onSaveLog: () -> Unit,
    isSavedToday: Boolean,
    modifier: Modifier = Modifier
) {
    ClayCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        backgroundColor = MaterialTheme.colorScheme.surface,
        elevation = 5.dp,
        contentPadding = PaddingValues(20.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.dashboard_daily_log_title),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (isSavedToday) {
                    ClayBadge(
                        text = stringResource(R.string.dashboard_saved_badge),
                        backgroundColor = ClayMintBg,
                        contentColor = SuccessGreen,
                        icon = Icons.Default.CheckCircle,
                        iconTint = SuccessGreen
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Two-column input for Income and Expense
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = incomeInput,
                    onValueChange = onIncomeChange,
                    label = { Text(stringResource(R.string.dashboard_income_label)) },
                    leadingIcon = {
                        Icon(Icons.Default.AttachMoney, contentDescription = stringResource(R.string.dashboard_income_label), tint = SuccessGreen)
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next),
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SuccessGreen,
                        focusedLabelColor = SuccessGreen
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("income_input")
                )

                OutlinedTextField(
                    value = expenseInput,
                    onValueChange = onExpenseChange,
                    label = { Text(stringResource(R.string.dashboard_expense_label)) },
                    leadingIcon = {
                        Icon(Icons.Default.MoneyOff, contentDescription = stringResource(R.string.dashboard_expense_label), tint = ExpenseRed)
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next),
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ExpenseRed,
                        focusedLabelColor = ExpenseRed
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("expense_input")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Work Hours input
            OutlinedTextField(
                value = hoursInput,
                onValueChange = onHoursChange,
                label = { Text(stringResource(R.string.dashboard_hours_label)) },
                leadingIcon = {
                    Icon(Icons.Default.Schedule, contentDescription = stringResource(R.string.dashboard_hours_label), tint = MaterialTheme.colorScheme.primary)
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next),
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hours_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Notes input
            OutlinedTextField(
                value = notesInput,
                onValueChange = onNotesChange,
                label = { Text(stringResource(R.string.dashboard_notes_label)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onSaveLog() }),
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("notes_input")
            )

            Spacer(modifier = Modifier.height(18.dp))

            // 3D Clay Save Button
            ClayButton(
                onClick = onSaveLog,
                text = stringResource(R.string.dashboard_save_button),
                leadingIcon = Icons.Default.CheckCircle,
                backgroundColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_log_button")
            )
        }
    }
}
