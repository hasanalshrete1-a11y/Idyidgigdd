package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Scheme Colors
val EmeraldPrimaryLight = Color(0xFF0D5C3A)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFA6F2C6)
val OnPrimaryContainerLight = Color(0xFF002111)

val AmberSecondaryLight = Color(0xFF8B5000)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFFFDDB8)
val OnSecondaryContainerLight = Color(0xFF2C1600)

val MintTertiaryLight = Color(0xFF006874)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFF9EEFFD)
val OnTertiaryContainerLight = Color(0xFF001F24)

val BackgroundLight = Color(0xFFF7FBF6)
val OnBackgroundLight = Color(0xFF191C1A)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF191C1A)
val SurfaceVariantLight = Color(0xFFDBE5DE)
val OnSurfaceVariantLight = Color(0xFF404944)
val OutlineLight = Color(0xFF707973)

// Dark Scheme Colors
val EmeraldPrimaryDark = Color(0xFF4ADE80)
val OnPrimaryDark = Color(0xFF003920)
val PrimaryContainerDark = Color(0xFF005230)
val OnPrimaryContainerDark = Color(0xFFA6F2C6)

val AmberSecondaryDark = Color(0xFFFBBF24)
val OnSecondaryDark = Color(0xFF4A2800)
val SecondaryContainerDark = Color(0xFF693C00)
val OnSecondaryContainerDark = Color(0xFFFFDDB8)

val MintTertiaryDark = Color(0xFF81D3E1)
val OnTertiaryDark = Color(0xFF00363D)
val TertiaryContainerDark = Color(0xFF004F58)
val OnTertiaryContainerDark = Color(0xFF9EEFFD)

val BackgroundDark = Color(0xFF111413)
val OnBackgroundDark = Color(0xFFE1E3DF)
val SurfaceDark = Color(0xFF181C1A)
val OnSurfaceDark = Color(0xFFE1E3DF)
val SurfaceVariantDark = Color(0xFF242A27)
val OnSurfaceVariantDark = Color(0xFFBFC9C2)
val OutlineDark = Color(0xFF8A938C)

// Custom Semantic Badges & Financial Indicators
val SuccessGreen = Color(0xFF16A34A)
val ExpenseRed = Color(0xFFDC2626)
val GoldRating = Color(0xFFF59E0B)
val InfoBlue = Color(0xFF2563EB)
val CardBorderSubtle = Color(0x1A000000)
val CardBorderSubtleDark = Color(0x26FFFFFF)
