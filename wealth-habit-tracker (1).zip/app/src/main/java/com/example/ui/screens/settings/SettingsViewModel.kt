package com.example.ui.screens.settings

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.PreferencesManager
import com.example.data.local.StorageManager
import com.example.data.local.entity.DailyLogEntry
import com.example.data.repository.FinanceRepository
import com.example.data.repository.HabitRepository
import com.example.data.repository.SecurityRepository
import com.example.notification.NotificationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LifetimeStats(
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val netSavings: Double = 0.0,
    val totalHours: Double = 0.0,
    val avgHourlyRate: Double = 0.0,
    val totalLogsCount: Int = 0
)

class SettingsViewModel(
    private val securityRepository: SecurityRepository,
    private val financeRepository: FinanceRepository,
    private val habitRepository: HabitRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    val appLanguage: StateFlow<String> = preferencesManager.appLanguageFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "en")

    val isPinEnabled: StateFlow<Boolean> = securityRepository.isPinEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val isBiometricEnabled: StateFlow<Boolean> = securityRepository.isBiometricEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val isReminderEnabled: StateFlow<Boolean> = securityRepository.isReminderEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val reminderHour: StateFlow<Int> = securityRepository.reminderHour
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 20)

    val reminderMinute: StateFlow<Int> = securityRepository.reminderMinute
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalCompletedHabits: StateFlow<Int> = habitRepository.totalCompletedCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val lifetimeStats: StateFlow<LifetimeStats> = financeRepository.allLogs.map { logs ->
        var income = 0.0
        var expense = 0.0
        var hours = 0.0
        logs.forEach {
            income += it.income
            expense += it.expense
            hours += it.workHours
        }
        val net = income - expense
        val avgRate = if (hours > 0.0) net / hours else 0.0
        LifetimeStats(
            totalIncome = income,
            totalExpense = expense,
            netSavings = net,
            totalHours = hours,
            avgHourlyRate = avgRate,
            totalLogsCount = logs.size
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LifetimeStats())

    fun setupNewPin(newPin: String) {
        viewModelScope.launch {
            securityRepository.setPin(newPin)
        }
    }

    fun disablePin() {
        viewModelScope.launch {
            securityRepository.disablePin()
        }
    }

    fun toggleBiometric(enabled: Boolean) {
        viewModelScope.launch {
            securityRepository.setBiometricEnabled(enabled)
        }
    }

    fun updateReminder(context: Context, enabled: Boolean, hour: Int, minute: Int) {
        viewModelScope.launch {
            securityRepository.updateReminderSchedule(enabled, hour, minute)
            if (enabled) {
                NotificationHelper.scheduleDailyReminder(context, hour, minute)
            } else {
                NotificationHelper.cancelReminder(context)
            }
        }
    }

    fun setAppLanguage(languageCode: String) {
        viewModelScope.launch {
            preferencesManager.setAppLanguage(languageCode)
        }
    }

    fun exportBackup(context: Context, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                val logs = financeRepository.allLogs.first()
                val habits = habitRepository.allHabits.first()
                val unlocked = preferencesManager.unlockedBooksFlow.first()
                val file = StorageManager.exportBackup(context, logs, habits, unlocked)
                if (file != null) {
                    onResult(true, "Backup saved to: Documents/FinancialApp/${file.name}")
                } else {
                    onResult(false, "Failed to export backup file")
                }
            } catch (e: Exception) {
                onResult(false, "Export error: ${e.message}")
            }
        }
    }

    fun restoreBackup(context: Context, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                val payload = StorageManager.readLatestBackup(context)
                if (payload != null) {
                    if (payload.logs.isNotEmpty()) {
                        financeRepository.insertAll(payload.logs)
                    }
                    if (payload.habits.isNotEmpty()) {
                        habitRepository.insertAllHabits(payload.habits)
                    }
                    for (bookId in payload.unlockedBooks) {
                        preferencesManager.unlockBook(bookId)
                    }
                    onResult(true, "Restored ${payload.logs.size} logs and ${payload.habits.size} habits from ${payload.exportDate}")
                } else {
                    onResult(false, "No backup file found in Documents/FinancialApp/")
                }
            } catch (e: Exception) {
                onResult(false, "Restore error: ${e.message}")
            }
        }
    }
}
