package com.example.ui.screens.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.BookSummary
import com.example.data.repository.EducationalRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class BookItemUi(
    val book: BookSummary,
    val isUnlocked: Boolean
)

class LibraryViewModel(
    private val educationalRepository: EducationalRepository
) : ViewModel() {

    val categories: List<String> = educationalRepository.getCategories()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    val unlockedBookIds: StateFlow<Set<String>> = educationalRepository.unlockedBookIds
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    val booksList: StateFlow<List<BookItemUi>> = combine(
        _selectedCategory,
        _searchQuery,
        unlockedBookIds
    ) { category, query, unlockedSet ->
        educationalRepository.getAllBooks()
            .filter { book ->
                val matchesCategory = category == "All" || book.category.equals(category, ignoreCase = true)
                val matchesQuery = query.isBlank() ||
                        book.title.contains(query, ignoreCase = true) ||
                        book.author.contains(query, ignoreCase = true) ||
                        book.teaser.contains(query, ignoreCase = true)
                matchesCategory && matchesQuery
            }
            .map { book ->
                BookItemUi(
                    book = book,
                    isUnlocked = book.isFreePreview || unlockedSet.contains(book.id)
                )
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun unlockBook(bookId: String) {
        viewModelScope.launch {
            educationalRepository.unlockBook(bookId)
        }
    }
}
