package com.example.ui.navigation

sealed class Screen(val route: String) {
    data object Dashboard : Screen("dashboard")
    data object Library : Screen("library")
    data object Settings : Screen("settings")
    data object Reader : Screen("reader/{bookId}") {
        fun createRoute(bookId: String): String = "reader/$bookId"
    }
}
