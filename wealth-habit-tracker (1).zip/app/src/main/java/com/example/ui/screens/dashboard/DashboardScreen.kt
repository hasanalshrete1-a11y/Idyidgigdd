package com.example.ui.screens.dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.stringResource
import com.example.R
import com.example.ui.theme.ClayBadge
import com.example.ui.theme.ClayButton
import com.example.ui.theme.ClayCard
import com.example.ui.theme.ClayMintBg
import com.example.ui.theme.ClayRoseBg
import com.example.ui.theme.ClaySkyBg
import com.example.ui.theme.ClayAmberBg
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.DailyLogEntry
import com.example.data.repository.HabitWithStatus
import com.example.ui.components.DailyLogInputSection
import com.example.ui.components.HourlyRateCard
import com.example.ui.components.StreakIndicator
import com.example.ui.components.WeeklyGrowthChart
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.GoldRating
import com.example.ui.theme.SuccessGreen
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    modifier: Modifier = Modifier
) {
    val incomeInput by viewModel.incomeInput.collectAsStateWithLifecycle()
    val expenseInput by viewModel.expenseInput.collectAsStateWithLifecycle()
    val hoursInput by viewModel.hoursInput.collectAsStateWithLifecycle()
    val notesInput by viewModel.notesInput.collectAsStateWithLifecycle()
    val isSavedToday by viewModel.isSavedToday.collectAsStateWithLifecycle()
    val streakDays by viewModel.streakDays.collectAsStateWithLifecycle()
    val weeklySummary by viewModel.weeklySummary.collectAsStateWithLifecycle()
    val habitsWithStatus by viewModel.habitsWithStatus.collectAsStateWithLifecycle()
    val recentLogs by viewModel.recentLogs.collectAsStateWithLifecycle()

    var showAddHabitDialog by remember { mutableStateOf(false) }

    val currentIncome = incomeInput.toDoubleOrNull() ?: 0.0
    val currentExpense = expenseInput.toDoubleOrNull() ?: 0.0
    val currentHours = hoursInput.toDoubleOrNull() ?: 0.0

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.dashboard_title),
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black)
                        )
                        Text(
                            text = stringResource(R.string.dashboard_header_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    ClayBadge(
                        text = stringResource(R.string.dashboard_streak_badge, streakDays),
                        backgroundColor = ClayAmberBg,
                        contentColor = Color(0xFF78350F),
                        icon = Icons.Default.LocalFireDepartment,
                        iconTint = GoldRating,
                        modifier = Modifier.padding(end = 16.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Streak Tracker Indicator
            item {
                StreakIndicator(
                    streakDays = streakDays,
                    modifier = Modifier.testTag("streak_indicator")
                )
            }

            // 2. Dynamic Hourly Rate Card (Income - Expense) / Work Hours
            item {
                HourlyRateCard(
                    income = currentIncome,
                    expense = currentExpense,
                    workHours = currentHours,
                    modifier = Modifier.testTag("hourly_rate_card")
                )
            }

            // Empty State Placeholder when user has not recorded any data yet
            if (recentLogs.isEmpty() && !isSavedToday) {
                item {
                    ClayCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("empty_state_card"),
                        shape = RoundedCornerShape(24.dp),
                        backgroundColor = MaterialTheme.colorScheme.surface,
                        elevation = 4.dp
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(ClaySkyBg),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Savings,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(32.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = stringResource(R.string.dashboard_empty_title),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = stringResource(R.string.dashboard_empty_subtitle),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            ClayButton(
                                text = stringResource(R.string.dashboard_empty_button),
                                onClick = { /* Focus is on daily log form right below */ },
                                backgroundColor = MaterialTheme.colorScheme.primary,
                                contentColor = Color.White,
                                leadingIcon = Icons.Default.Add,
                                modifier = Modifier.fillMaxWidth(0.75f).testTag("add_log_empty_btn")
                            )
                        }
                    }
                }
            }

            // 3. Daily Logging Form (Income, Expense, Hours, Notes)
            item {
                DailyLogInputSection(
                    incomeInput = incomeInput,
                    onIncomeChange = viewModel::onIncomeChange,
                    expenseInput = expenseInput,
                    onExpenseChange = viewModel::onExpenseChange,
                    hoursInput = hoursInput,
                    onHoursChange = viewModel::onHoursChange,
                    notesInput = notesInput,
                    onNotesChange = viewModel::onNotesChange,
                    onSaveLog = viewModel::saveTodayLog,
                    isSavedToday = isSavedToday
                )
            }

            // 4. Dynamic Weekly Growth Chart (Progress, Growing vs Overspending)
            item {
                WeeklyGrowthChart(
                    summary = weeklySummary,
                    modifier = Modifier.testTag("weekly_growth_chart")
                )
            }

            // 5. Daily Habits Section
            item {
                HabitsSection(
                    habits = habitsWithStatus,
                    onToggleHabit = { habitItem -> viewModel.toggleHabit(habitItem.habit) },
                    onAddHabitClick = { showAddHabitDialog = true }
                )
            }

            // 6. Recent Logs History
            if (recentLogs.isNotEmpty()) {
                item {
                    Text(
                        text = stringResource(R.string.dashboard_recent_logs),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                items(recentLogs, key = { it.id }) { log ->
                    RecentLogCard(log = log)
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    if (showAddHabitDialog) {
        AddHabitDialog(
            onDismiss = { showAddHabitDialog = false },
            onAdd = { name, category ->
                viewModel.addCustomHabit(name, category)
                showAddHabitDialog = false
            }
        )
    }
}

@Composable
private fun HabitsSection(
    habits: List<HabitWithStatus>,
    onToggleHabit: (HabitWithStatus) -> Unit,
    onAddHabitClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    ClayCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        backgroundColor = MaterialTheme.colorScheme.surface,
        elevation = 5.dp
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = stringResource(R.string.dashboard_habits_title),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = stringResource(R.string.dashboard_habits_subtitle),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(
                    onClick = onAddHabitClick,
                    modifier = Modifier.testTag("add_habit_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = stringResource(R.string.dashboard_add_habit),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (habits.isEmpty()) {
                Text(
                    text = stringResource(R.string.dashboard_habits_empty),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    habits.forEach { item ->
                        HabitRowItem(
                            item = item,
                            onToggle = { onToggleHabit(item) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HabitRowItem(
    item: HabitWithStatus,
    onToggle: () -> Unit
) {
    val habit = item.habit
    ClayCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle),
        shape = RoundedCornerShape(18.dp),
        backgroundColor = if (item.isCompletedToday) ClayMintBg else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        elevation = 2.dp,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Checkbox(
                    checked = item.isCompletedToday,
                    onCheckedChange = { onToggle() },
                    colors = CheckboxDefaults.colors(
                        checkedColor = SuccessGreen
                    ),
                    modifier = Modifier.testTag("habit_check_${habit.id}")
                )
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = habit.name,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = if (item.isCompletedToday) FontWeight.Bold else FontWeight.Medium
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = habit.category,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Streak 3D Clay pill
            ClayBadge(
                text = "${habit.streakCount}d",
                backgroundColor = Color.White,
                contentColor = if (habit.streakCount > 0) Color(0xFF78350F) else MaterialTheme.colorScheme.outline,
                icon = Icons.Default.LocalFireDepartment,
                iconTint = if (habit.streakCount > 0) GoldRating else MaterialTheme.colorScheme.outline
            )
        }
    }
}

@Composable
private fun RecentLogCard(log: DailyLogEntry) {
    ClayCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        backgroundColor = MaterialTheme.colorScheme.surface,
        elevation = 3.dp,
        contentPadding = PaddingValues(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = log.date,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
                if (log.notes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = log.notes,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.dashboard_recent_hrs_worked, String.format(Locale.US, "%.1f", log.workHours)),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "+$${String.format(Locale.US, "%.2f", log.income)}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = SuccessGreen
                )
                Text(
                    text = "-$${String.format(Locale.US, "%.2f", log.expense)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = ExpenseRed
                )
                Text(
                    text = "$${String.format(Locale.US, "%.2f", log.effectiveHourlyRate)}/hr",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun AddHabitDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, category: String) -> Unit
) {
    var habitName by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Productivity") }
    val categories = listOf(
        "Productivity" to R.string.category_productivity,
        "Finance" to R.string.category_finance,
        "Growth" to R.string.category_growth,
        "Health" to R.string.category_health,
        "Freelance" to R.string.category_freelance
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.dashboard_add_habit_dialog_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = habitName,
                    onValueChange = { habitName = it },
                    label = { Text(stringResource(R.string.dashboard_add_habit_name_label)) },
                    placeholder = { Text(stringResource(R.string.dashboard_add_habit_name_placeholder)) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("habit_name_input")
                )

                Text(
                    text = stringResource(R.string.dashboard_add_habit_category_label),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.take(3).forEach { (catKey, catRes) ->
                        val isSelected = selectedCategory == catKey
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable { selectedCategory = catKey }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = stringResource(catRes),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (habitName.isNotBlank()) {
                        onAdd(habitName, selectedCategory)
                    }
                },
                modifier = Modifier.testTag("confirm_add_habit")
            ) {
                Text(stringResource(R.string.dashboard_add_habit_confirm))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.dashboard_dialog_cancel))
            }
        }
    )
}
