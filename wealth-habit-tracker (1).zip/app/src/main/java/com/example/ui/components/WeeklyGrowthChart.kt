package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.repository.WeeklyFinancialSummary
import com.example.ui.theme.ClayBadge
import com.example.ui.theme.ClayCard
import com.example.ui.theme.ClayMintBg
import com.example.ui.theme.ClayRoseBg
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.SuccessGreen
import java.util.Locale

@Composable
fun WeeklyGrowthChart(
    summary: WeeklyFinancialSummary,
    modifier: Modifier = Modifier
) {
    val hasData = summary.totalIncome > 0.0 || summary.totalExpense > 0.0

    ClayCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        backgroundColor = MaterialTheme.colorScheme.surface,
        elevation = 5.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            // Header Row with growth / overspending indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = stringResource(R.string.chart_pulse_title),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = stringResource(R.string.chart_pulse_subtitle),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Growth vs Overspending status badge
                val badgeText = when {
                    !hasData -> stringResource(R.string.chart_status_no_data)
                    summary.isGrowing -> stringResource(R.string.chart_status_growing, summary.savingsRatePercentage)
                    summary.totalIncome == 0.0 && summary.totalExpense == 0.0 -> stringResource(R.string.chart_status_balanced)
                    else -> stringResource(R.string.chart_status_overspending)
                }
                val isPositive = summary.isGrowing || !hasData

                ClayBadge(
                    text = badgeText,
                    backgroundColor = if (isPositive) ClayMintBg else ClayRoseBg,
                    contentColor = if (isPositive) SuccessGreen else ExpenseRed,
                    icon = if (isPositive) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                    iconTint = if (isPositive) SuccessGreen else ExpenseRed
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Net summary metrics
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = stringResource(R.string.chart_total_income),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "$${String.format(Locale.US, "%.2f", summary.totalIncome)}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = SuccessGreen
                    )
                }
                Column {
                    Text(
                        text = stringResource(R.string.chart_total_expense),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "$${String.format(Locale.US, "%.2f", summary.totalExpense)}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = ExpenseRed
                    )
                }
                Column {
                    Text(
                        text = stringResource(R.string.chart_net_saved),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${if (summary.netSavings >= 0) "+" else ""}$${String.format(Locale.US, "%.2f", summary.netSavings)}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (summary.netSavings >= 0) MaterialTheme.colorScheme.primary else ExpenseRed
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Canvas Bar Chart
            val incomeColor = SuccessGreen
            val expenseColor = ExpenseRed
            val gridLineColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
            val textColor = MaterialTheme.colorScheme.onSurfaceVariant

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                Canvas(modifier = Modifier.matchParentSize()) {
                    val points = summary.dailyPoints
                    if (points.isEmpty()) return@Canvas

                    val maxVal = points.maxOfOrNull { maxOf(it.income, it.expense) }?.coerceAtLeast(50.0) ?: 100.0
                    val width = size.width
                    val height = size.height
                    val bottomPadding = 24.dp.toPx()
                    val chartHeight = height - bottomPadding
                    val count = points.size
                    val stepX = width / count

                    // Draw subtle horizontal guideline
                    drawLine(
                        color = gridLineColor,
                        start = Offset(0f, chartHeight),
                        end = Offset(width, chartHeight),
                        strokeWidth = 1.dp.toPx()
                    )

                    val barWidth = 8.dp.toPx()
                    val cornerRad = CornerRadius(4.dp.toPx(), 4.dp.toPx())

                    points.forEachIndexed { index, point ->
                        val centerX = (index * stepX) + (stepX / 2f)

                        // Income Bar (left of center)
                        val incomeHeight = ((point.income / maxVal) * chartHeight * 0.85f).toFloat().coerceAtLeast(2f)
                        val incomeLeft = centerX - barWidth - 1.dp.toPx()
                        val incomeTop = chartHeight - incomeHeight

                        drawRoundRect(
                            color = incomeColor,
                            topLeft = Offset(incomeLeft, incomeTop),
                            size = Size(barWidth, incomeHeight),
                            cornerRadius = cornerRad
                        )

                        // Expense Bar (right of center)
                        val expenseHeight = ((point.expense / maxVal) * chartHeight * 0.85f).toFloat().coerceAtLeast(2f)
                        val expenseLeft = centerX + 1.dp.toPx()
                        val expenseTop = chartHeight - expenseHeight

                        drawRoundRect(
                            color = expenseColor,
                            topLeft = Offset(expenseLeft, expenseTop),
                            size = Size(barWidth, expenseHeight),
                            cornerRadius = cornerRad
                        )

                        // Day of week label
                        drawContext.canvas.nativeCanvas.apply {
                            val paint = android.graphics.Paint().apply {
                                color = android.graphics.Color.GRAY
                                textSize = 11.sp.toPx()
                                textAlign = android.graphics.Paint.Align.CENTER
                                isAntiAlias = true
                            }
                            drawText(
                                point.dayLabel,
                                centerX,
                                height - 4.dp.toPx(),
                                paint
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Chart Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(SuccessGreen))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = stringResource(R.string.chart_legend_income), style = MaterialTheme.typography.labelSmall)

                Spacer(modifier = Modifier.width(20.dp))

                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(ExpenseRed))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = stringResource(R.string.chart_legend_expense), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
