package com.example.ui.screens.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.DailyLogEntry
import com.example.data.local.entity.HabitEntity
import com.example.data.repository.DailyChartPoint
import com.example.data.repository.FinanceRepository
import com.example.data.repository.HabitRepository
import com.example.data.repository.HabitWithStatus
import com.example.data.repository.WeeklyFinancialSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class DashboardUiState(
    val selectedDate: String = "",
    val incomeInput: String = "",
    val expenseInput: String = "",
    val hoursInput: String = "",
    val notesInput: String = "",
    val isSavedToday: Boolean = false,
    val streakDays: Int = 0,
    val weeklySummary: WeeklyFinancialSummary = WeeklyFinancialSummary(
        totalIncome = 0.0,
        totalExpense = 0.0,
        netSavings = 0.0,
        totalHours = 0.0,
        avgHourlyRate = 0.0,
        isGrowing = true,
        savingsRatePercentage = 0.0,
        dailyPoints = emptyList()
    ),
    val habits: List<HabitWithStatus> = emptyList(),
    val recentLogs: List<DailyLogEntry> = emptyList()
)

class DashboardViewModel(
    private val financeRepository: FinanceRepository,
    private val habitRepository: HabitRepository
) : ViewModel() {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val todayDate: String = dateFormat.format(Calendar.getInstance().time)

    private val _incomeInput = MutableStateFlow("")
    val incomeInput = _incomeInput.asStateFlow()

    private val _expenseInput = MutableStateFlow("")
    val expenseInput = _expenseInput.asStateFlow()

    private val _hoursInput = MutableStateFlow("")
    val hoursInput = _hoursInput.asStateFlow()

    private val _notesInput = MutableStateFlow("")
    val notesInput = _notesInput.asStateFlow()

    private val _isSavedToday = MutableStateFlow(false)

    val streakDays: StateFlow<Int> = financeRepository.getLoggingStreakFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val weeklySummary: StateFlow<WeeklyFinancialSummary> = financeRepository.getWeeklySummaryFlow()
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            WeeklyFinancialSummary(0.0, 0.0, 0.0, 0.0, 0.0, true, 0.0, emptyList())
        )

    val habitsWithStatus: StateFlow<List<HabitWithStatus>> = habitRepository.getHabitsWithTodayStatus(todayDate)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentLogs: StateFlow<List<DailyLogEntry>> = financeRepository.getRecentLogs(7)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        loadTodayLog()
    }

    private fun loadTodayLog() {
        viewModelScope.launch {
            val existing = financeRepository.getTodayLogSync(todayDate)
            if (existing != null) {
                _incomeInput.value = if (existing.income > 0) String.format(Locale.US, "%.2f", existing.income) else ""
                _expenseInput.value = if (existing.expense > 0) String.format(Locale.US, "%.2f", existing.expense) else ""
                _hoursInput.value = if (existing.workHours > 0) String.format(Locale.US, "%.1f", existing.workHours) else ""
                _notesInput.value = existing.notes
                _isSavedToday.value = true
            }
        }
    }

    fun onIncomeChange(value: String) {
        _incomeInput.value = value.filter { it.isDigit() || it == '.' }
    }

    fun onExpenseChange(value: String) {
        _expenseInput.value = value.filter { it.isDigit() || it == '.' }
    }

    fun onHoursChange(value: String) {
        _hoursInput.value = value.filter { it.isDigit() || it == '.' }
    }

    fun onNotesChange(value: String) {
        _notesInput.value = value
    }

    fun saveTodayLog() {
        val incomeVal = _incomeInput.value.toDoubleOrNull() ?: 0.0
        val expenseVal = _expenseInput.value.toDoubleOrNull() ?: 0.0
        val hoursVal = _hoursInput.value.toDoubleOrNull() ?: 0.0
        val notesVal = _notesInput.value.trim()

        viewModelScope.launch {
            val existing = financeRepository.getTodayLogSync(todayDate)
            val entry = DailyLogEntry(
                id = existing?.id ?: 0L,
                date = todayDate,
                income = incomeVal,
                expense = expenseVal,
                workHours = hoursVal,
                notes = notesVal,
                timestamp = System.currentTimeMillis()
            )
            financeRepository.insertOrUpdate(entry)
            _isSavedToday.value = true
        }
    }

    fun toggleHabit(habit: HabitEntity) {
        viewModelScope.launch {
            habitRepository.toggleHabitCompletion(habit, todayDate)
        }
    }

    fun addCustomHabit(name: String, category: String) {
        viewModelScope.launch {
            if (name.isNotBlank()) {
                habitRepository.addHabit(name.trim(), category)
            }
        }
    }

    val isSavedToday: StateFlow<Boolean> = _isSavedToday.asStateFlow()
}
