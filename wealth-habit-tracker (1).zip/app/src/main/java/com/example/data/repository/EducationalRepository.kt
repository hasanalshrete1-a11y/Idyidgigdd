package com.example.data.repository

import com.example.data.local.PreferencesManager
import com.example.data.model.BookSummary
import com.example.data.model.PrincipleItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class EducationalRepository(
    private val preferencesManager: PreferencesManager
) {
    val unlockedBookIds: Flow<Set<String>> = preferencesManager.unlockedBooksFlow

    suspend fun unlockBook(bookId: String) {
        preferencesManager.unlockBook(bookId)
    }

    fun getAllBooks(): List<BookSummary> = bookCatalog

    fun getBookById(id: String): BookSummary? = bookCatalog.find { it.id == id }

    fun getCategories(): List<String> = listOf(
        "All",
        "Financial Mindset",
        "Productivity & Habits",
        "Freelancing & Income",
        "Investing & Wealth"
    )

    private val bookCatalog = listOf(
        BookSummary(
            id = "psychology_of_money",
            title = "The Psychology of Money",
            author = "Morgan Housel",
            category = "Financial Mindset",
            readTimeMinutes = 8,
            teaser = "Doing well with money isn't necessarily about what you know. It's about how you behave.",
            keyQuote = "Spending money to show people how much money you have is the fastest way to have less money.",
            coreThesis = "Financial success is not a hard science. It's a soft skill, where how you behave is more important than what you know. Controlling your time is the highest dividend money pays.",
            keyPrinciples = listOf(
                PrincipleItem(
                    "Freedom over Luxury",
                    "The highest form of wealth is the ability to wake up every morning and say, 'I can do whatever I want today.'"
                ),
                PrincipleItem(
                    "Compounding Requires Survival",
                    "More than big returns, you want financial endurance. If you can survive market downturns without panicking, compounding works miracles."
                ),
                PrincipleItem(
                    "Wealth is What You Don't See",
                    "Wealth consists of the cars not purchased, the diamonds not bought, the first-class upgrades declined. Wealth is financial options preserved."
                ),
                PrincipleItem(
                    "Reasonable > Strictly Rational",
                    "Do not aim to be cold and mathematically optimal. Aim to be financially reasonable and sleep peacefully at night."
                )
            ),
            actionChecklist = listOf(
                "Maintain a 6-month liquid cash emergency fund regardless of opportunity cost.",
                "Define your 'Enough' baseline to prevent continuous lifestyle creep.",
                "Automate regular index fund contributions every pay cycle.",
                "Review purchases by evaluating the work hours required to earn that amount."
            ),
            isFreePreview = true
        ),
        BookSummary(
            id = "atomic_habits",
            title = "Atomic Habits",
            author = "James Clear",
            category = "Productivity & Habits",
            readTimeMinutes = 9,
            teaser = "Tiny changes, remarkable results. 1% better every day yields a 37x compounding effect over one year.",
            keyQuote = "You do not rise to the level of your goals. You fall to the level of your systems.",
            coreThesis = "Habits are the compound interest of self-improvement. By designing frictionless environments and stacking daily identity-based cues, lasting transformation becomes effortless.",
            keyPrinciples = listOf(
                PrincipleItem(
                    "Identity-Based Habits",
                    "Focus not on what you want to achieve, but on who you wish to become. Every action you take is a vote for the type of person you wish to be."
                ),
                PrincipleItem(
                    "The 4 Laws of Behavior Change",
                    "Make it Obvious, Make it Attractive, Make it Easy, and Make it Satisfying."
                ),
                PrincipleItem(
                    "The Two-Minute Rule",
                    "When starting a new habit, scale it down until it takes two minutes or less. Read one page, do two pushups, log one expense."
                ),
                PrincipleItem(
                    "Never Miss Twice",
                    "Missing once is an accident. Missing twice is the start of a new, negative habit. Reset quickly on off days."
                )
            ),
            actionChecklist = listOf(
                "Identify your keystone habit: Log daily expenses right after morning coffee.",
                "Use habit stacking: 'After I sit at my desk, I will start a 60-minute deep work timer.'",
                "Reduce friction: Keep your financial dashboard one tap away on your home screen.",
                "Track streaks visually every day without breaking the chain."
            )
        ),
        BookSummary(
            id = "freelance_manifesto",
            title = "The Freelance Manifesto",
            author = "Joey Korenman",
            category = "Freelancing & Income",
            readTimeMinutes = 7,
            teaser = "A step-by-step blueprint for taking control of your career, rates, and client pipeline as an independent professional.",
            keyQuote = "Price yourself based on the value delivered, not the anxiety in your stomach.",
            coreThesis = "Freelancers often struggle not due to talent, but due to inconsistent client acquisition and undercharging. Treating freelancing as a professional business creates autonomy and 3x income.",
            keyPrinciples = listOf(
                PrincipleItem(
                    "Value-Based Hourly Floor",
                    "Calculate your true effective hourly rate: (Net Income - Software/Tax Expenses) divided by actual hours worked. Guard this rate strictly."
                ),
                PrincipleItem(
                    "The Warm Outreach Pipeline",
                    "Dedicate 30 minutes every morning to nurturing 3 client relationships before opening any client production work."
                ),
                PrincipleItem(
                    "Kill the Feast or Famine Cycle",
                    "Market when you are busy, not when you run out of cash. Consistent pipeline activity prevents panic discounts."
                )
            ),
            actionChecklist = listOf(
                "Calculate your baseline minimum hourly target rate in the Freedom Tracker.",
                "Audit your last 5 client projects: identify which paid above vs below your hourly floor.",
                "Send 3 personalized follow-ups to past satisfied clients this week.",
                "Say 'no' to low-margin projects that consume high emotional energy."
            )
        ),
        BookSummary(
            id = "simple_path_wealth",
            title = "The Simple Path to Wealth",
            author = "JL Collins",
            category = "Investing & Wealth",
            readTimeMinutes = 8,
            teaser = "The definitive road map to financial independence and a rich, free life through low-cost total market index funds.",
            keyQuote = "Stop thinking about what your money can buy. Start thinking about what your money can earn.",
            coreThesis = "Complex investing strategies enrich the financial industry, not you. A simple strategy of low expenses, avoiding debt, living on less than you make, and investing in low-cost index funds builds bulletproof wealth.",
            keyPrinciples = listOf(
                PrincipleItem(
                    "F-You Money",
                    "Having a stockpile of savings that allows you to walk away from toxic bosses, bad projects, or soul-crushing jobs."
                ),
                PrincipleItem(
                    "The Magic of Total Market Indexing",
                    "Don't search for needles in the haystack. Buy the entire haystack (e.g., broad market index funds with ultra-low expense ratios)."
                ),
                PrincipleItem(
                    "Ignore the Noise",
                    "Market downturns are not reasons to sell; they are flash sales. Never panic sell during market corrections."
                )
            ),
            actionChecklist = listOf(
                "Eliminate all high-interest consumer debt aggressively.",
                "Target an ongoing savings rate of 30% to 50% of your take-home pay.",
                "Automate regular monthly index fund transfers.",
                "Calculate your Financial Independence number: 25x your annual essential expenses."
            )
        ),
        BookSummary(
            id = "deep_work",
            title = "Deep Work",
            author = "Cal Newport",
            category = "Productivity & Habits",
            readTimeMinutes = 8,
            teaser = "Rules for focused success in a distracted world: deep work is the superpower of the 21st century economy.",
            keyQuote = "If you don't produce, you won't thrive—no matter how skilled or talented you are.",
            coreThesis = "The ability to perform deep work is becoming increasingly rare at exactly the same time it is becoming increasingly valuable. Those who cultivate this skill will command top market rates.",
            keyPrinciples = listOf(
                PrincipleItem(
                    "High-Value Output Formula",
                    "High-Quality Work Produced = (Time Spent) x (Intensity of Focus). Eliminate multitasking completely."
                ),
                PrincipleItem(
                    "Ruthlessly Protect Time Blocks",
                    "Schedule two unbroken 90-minute blocks each day. Treat them like appointments with high-paying clients."
                ),
                PrincipleItem(
                    "Quit Superficial Metrics",
                    "Distinguish between shallow work (answering emails, slack chat) and deep work (coding, writing, strategy)."
                )
            ),
            actionChecklist = listOf(
                "Schedule a 90-minute deep work block for tomorrow morning before checking notifications.",
                "Log your dedicated deep work hours inside the Freedom Tracker daily.",
                "Install website blockers on social media during work hours.",
                "Perform a shut-down ritual at the end of every work day to allow psychological recovery."
            )
        ),
        BookSummary(
            id = "millionaire_fastlane",
            title = "The Millionaire Fastlane",
            author = "MJ DeMarco",
            category = "Financial Mindset",
            readTimeMinutes = 9,
            teaser = "Crack the code to wealth and live rich for a lifetime by decoupling income from time and building asymmetric systems.",
            keyQuote = "Instead of digging for gold, sell shovels. Instead of taking the course, sell the course.",
            coreThesis = "Trading time for dollars in a slowlane job caps your wealth upside. Fastlane wealth is built on systems, scalable products, and asymmetric upside governed by the C-E-N-T-S framework (Control, Entry, Need, Time, Scale).",
            keyPrinciples = listOf(
                PrincipleItem(
                    "The CENTS Framework",
                    "Control (own the asset), Entry (high barriers to competition), Need (solve real human pain), Time (detached from hours), Scale (large market)."
                ),
                PrincipleItem(
                    "Divorce Time from Earnings",
                    "If your earnings drop to zero whenever you stop working, you own a job, not a wealth-generating business."
                ),
                PrincipleItem(
                    "Produce Rather Than Consume",
                    "Switch your mindset from being a consumer (buying gadgets) to a producer (building tools, content, software)."
                )
            ),
            actionChecklist = listOf(
                "Evaluate your current income stream against the C-E-N-T-S framework.",
                "Identify one digital or service asset you can package and sell repeatedly.",
                "Track how much of your work day is spent on scalable systems versus manual tasks.",
                "Reinvest net profit from today into building long-term equity."
            )
        )
    )
}
