package com.example.data.model

data class BookSummary(
    val id: String,
    val title: String,
    val author: String,
    val category: String,
    val readTimeMinutes: Int,
    val teaser: String,
    val keyQuote: String,
    val coreThesis: String,
    val keyPrinciples: List<PrincipleItem>,
    val actionChecklist: List<String>,
    val isFreePreview: Boolean = false
)

data class PrincipleItem(
    val title: String,
    val description: String
)
