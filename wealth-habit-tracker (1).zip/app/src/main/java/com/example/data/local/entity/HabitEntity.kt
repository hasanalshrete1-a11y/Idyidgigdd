package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val category: String = "Productivity",
    val streakCount: Int = 0,
    val bestStreak: Int = 0,
    val lastCompletedDate: String? = null,
    val isCompletedToday: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
