package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.DailyLogDao
import com.example.data.local.dao.HabitDao
import com.example.data.local.entity.DailyLogEntry
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.HabitLogEntity

@Database(
    entities = [DailyLogEntry::class, HabitEntity::class, HabitLogEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dailyLogDao(): DailyLogDao
    abstract fun habitDao(): HabitDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "freedom_tracker_v2.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
