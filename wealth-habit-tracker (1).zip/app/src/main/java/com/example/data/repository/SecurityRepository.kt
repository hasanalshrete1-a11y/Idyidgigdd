package com.example.data.repository

import com.example.data.local.PreferencesManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class SecurityRepository(private val preferencesManager: PreferencesManager) {

    val isPinEnabled: Flow<Boolean> = preferencesManager.isPinEnabledFlow
    val isBiometricEnabled: Flow<Boolean> = preferencesManager.isBiometricEnabledFlow
    val pinCodeFlow: Flow<String?> = preferencesManager.pinCodeFlow
    val isReminderEnabled: Flow<Boolean> = preferencesManager.isReminderEnabledFlow
    val reminderHour: Flow<Int> = preferencesManager.reminderHourFlow
    val reminderMinute: Flow<Int> = preferencesManager.reminderMinuteFlow

    suspend fun verifyPin(inputPin: String): Boolean {
        val storedPin = preferencesManager.pinCodeFlow.firstOrNull()
        return storedPin != null && storedPin == inputPin
    }

    suspend fun setPin(newPin: String) {
        preferencesManager.savePin(newPin)
    }

    suspend fun disablePin() {
        preferencesManager.removePin()
    }

    suspend fun setBiometricEnabled(enabled: Boolean) {
        preferencesManager.setBiometricEnabled(enabled)
    }

    suspend fun updateReminderSchedule(enabled: Boolean, hour: Int, minute: Int) {
        preferencesManager.setReminderSettings(enabled, hour, minute)
    }
}
