package com.example.data.repository

import com.example.data.local.dao.HabitDao
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.HabitLogEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class HabitWithStatus(
    val habit: HabitEntity,
    val isCompletedToday: Boolean
)

class HabitRepository(private val habitDao: HabitDao) {

    val allHabits: Flow<List<HabitEntity>> = habitDao.getAllHabits()

    fun getHabitsWithTodayStatus(todayDate: String): Flow<List<HabitWithStatus>> {
        return combine(
            habitDao.getAllHabits(),
            habitDao.getHabitLogsForDate(todayDate)
        ) { habits, logs ->
            val completedHabitIds = logs.filter { it.isCompleted }.map { it.habitId }.toSet()
            habits.map { habit ->
                HabitWithStatus(
                    habit = habit,
                    isCompletedToday = completedHabitIds.contains(habit.id)
                )
            }
        }
    }

    suspend fun toggleHabitCompletion(habit: HabitEntity, todayDate: String) {
        val existingLog = habitDao.getHabitLog(habit.id, todayDate)
        if (existingLog != null && existingLog.isCompleted) {
            // Uncheck
            habitDao.deleteHabitLog(habit.id, todayDate)
            val newStreak = (habit.streakCount - 1).coerceAtLeast(0)
            habitDao.updateHabit(
                habit.copy(
                    streakCount = newStreak,
                    isCompletedToday = false
                )
            )
        } else {
            // Check off
            habitDao.insertHabitLog(
                HabitLogEntity(
                    habitId = habit.id,
                    date = todayDate,
                    isCompleted = true
                )
            )
            val newStreak = habit.streakCount + 1
            val best = maxOf(habit.bestStreak, newStreak)
            habitDao.updateHabit(
                habit.copy(
                    streakCount = newStreak,
                    bestStreak = best,
                    lastCompletedDate = todayDate,
                    isCompletedToday = true
                )
            )
        }
    }

    suspend fun addHabit(name: String, category: String) {
        habitDao.insertHabit(
            HabitEntity(
                name = name,
                category = category,
                streakCount = 0,
                bestStreak = 0
            )
        )
    }

    suspend fun insertAllHabits(habits: List<HabitEntity>) {
        habitDao.insertAllHabits(habits)
    }

    suspend fun deleteHabit(habitId: Long) {
        habitDao.deleteHabit(habitId)
    }

    val totalCompletedCount: Flow<Int> = habitDao.getTotalCompletedHabitsCount()
}
