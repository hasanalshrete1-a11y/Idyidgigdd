package com.example.data.local

import android.content.Context
import android.os.Environment
import android.util.Log
import com.example.data.local.entity.DailyLogEntry
import com.example.data.local.entity.HabitEntity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BackupPayload(
    val exportDate: String,
    val logs: List<DailyLogEntry>,
    val habits: List<HabitEntity>,
    val unlockedBooks: Set<String>
)

object StorageManager {
    private const val TAG = "StorageManager"
    private const val FOLDER_NAME = "FinancialApp"
    const val MAIN_DATA_FILE = "financial_data.json"

    fun getStorageFolder(context: Context): File {
        return try {
            val publicDocs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            val dir = File(publicDocs, FOLDER_NAME)
            if (!dir.exists()) {
                val created = dir.mkdirs()
                if (!created) {
                    val appSpecific = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), FOLDER_NAME)
                    appSpecific.mkdirs()
                    return appSpecific
                }
            }
            dir
        } catch (e: Exception) {
            Log.e(TAG, "Failed accessing public Documents, falling back", e)
            val appSpecific = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), FOLDER_NAME)
            appSpecific.mkdirs()
            appSpecific
        }
    }

    fun exportBackup(
        context: Context,
        logs: List<DailyLogEntry>,
        habits: List<HabitEntity>,
        unlockedBooks: Set<String>
    ): File? {
        return try {
            val folder = getStorageFolder(context)
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val backupFile = File(folder, "financial_backup_$timestamp.json")
            val mainFile = File(folder, MAIN_DATA_FILE)

            val json = serializeToJson(logs, habits, unlockedBooks)

            // Write both timestamped backup and canonical current data file
            backupFile.writeText(json)
            mainFile.writeText(json)

            Log.i(TAG, "Successfully exported backup to ${backupFile.absolutePath}")
            backupFile
        } catch (e: Exception) {
            Log.e(TAG, "Failed exporting backup", e)
            null
        }
    }

    fun readLatestBackup(context: Context): BackupPayload? {
        return try {
            val folder = getStorageFolder(context)
            val mainFile = File(folder, MAIN_DATA_FILE)
            val fileToRead = if (mainFile.exists()) {
                mainFile
            } else {
                folder.listFiles { file -> file.name.startsWith("financial_backup_") && file.name.endsWith(".json") }
                    ?.maxByOrNull { it.lastModified() }
            }

            if (fileToRead == null || !fileToRead.exists()) {
                return null
            }

            val jsonStr = fileToRead.readText()
            parseFromJson(jsonStr)
        } catch (e: Exception) {
            Log.e(TAG, "Failed reading backup", e)
            null
        }
    }

    fun getStorageDisplayPath(context: Context): String {
        return try {
            val folder = getStorageFolder(context)
            "Documents/$FOLDER_NAME/${folder.name}"
        } catch (e: Exception) {
            "Documents/$FOLDER_NAME"
        }
    }

    private fun serializeToJson(
        logs: List<DailyLogEntry>,
        habits: List<HabitEntity>,
        unlockedBooks: Set<String>
    ): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("exportDate", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()))

        // Logs Array
        val logsArray = JSONArray()
        for (log in logs) {
            val item = JSONObject()
            item.put("id", log.id)
            item.put("date", log.date)
            item.put("income", log.income)
            item.put("expense", log.expense)
            item.put("workHours", log.workHours)
            item.put("notes", log.notes)
            item.put("timestamp", log.timestamp)
            logsArray.put(item)
        }
        root.put("daily_logs", logsArray)

        // Habits Array
        val habitsArray = JSONArray()
        for (habit in habits) {
            val item = JSONObject()
            item.put("id", habit.id)
            item.put("name", habit.name)
            item.put("category", habit.category)
            item.put("streakCount", habit.streakCount)
            item.put("bestStreak", habit.bestStreak)
            item.put("lastCompletedDate", habit.lastCompletedDate ?: "")
            item.put("isCompletedToday", habit.isCompletedToday)
            item.put("createdAt", habit.createdAt)
            habitsArray.put(item)
        }
        root.put("habits", habitsArray)

        // Unlocked Books Set
        val booksArray = JSONArray()
        for (bookId in unlockedBooks) {
            booksArray.put(bookId)
        }
        root.put("unlocked_books", booksArray)

        return root.toString(2)
    }

    private fun parseFromJson(jsonStr: String): BackupPayload {
        val root = JSONObject(jsonStr)
        val exportDate = root.optString("exportDate", "Unknown")

        val logsList = mutableListOf<DailyLogEntry>()
        val logsArray = root.optJSONArray("daily_logs") ?: JSONArray()
        for (i in 0 until logsArray.length()) {
            val obj = logsArray.getJSONObject(i)
            logsList.add(
                DailyLogEntry(
                    id = obj.optLong("id", 0L),
                    date = obj.optString("date", ""),
                    income = obj.optDouble("income", 0.0),
                    expense = obj.optDouble("expense", 0.0),
                    workHours = obj.optDouble("workHours", 0.0),
                    notes = obj.optString("notes", ""),
                    timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                )
            )
        }

        val habitsList = mutableListOf<HabitEntity>()
        val habitsArray = root.optJSONArray("habits") ?: JSONArray()
        for (i in 0 until habitsArray.length()) {
            val obj = habitsArray.getJSONObject(i)
            habitsList.add(
                HabitEntity(
                    id = obj.optLong("id", 0L),
                    name = obj.optString("name", ""),
                    category = obj.optString("category", "General"),
                    streakCount = obj.optInt("streakCount", 0),
                    bestStreak = obj.optInt("bestStreak", 0),
                    lastCompletedDate = obj.optString("lastCompletedDate").takeIf { it.isNotBlank() },
                    isCompletedToday = obj.optBoolean("isCompletedToday", false),
                    createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                )
            )
        }

        val unlockedBooks = mutableSetOf<String>()
        val booksArray = root.optJSONArray("unlocked_books") ?: JSONArray()
        for (i in 0 until booksArray.length()) {
            unlockedBooks.add(booksArray.getString(i))
        }

        return BackupPayload(
            exportDate = exportDate,
            logs = logsList,
            habits = habitsList,
            unlockedBooks = unlockedBooks
        )
    }
}
