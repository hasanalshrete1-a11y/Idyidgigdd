package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.DailyLogEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyLogDao {
    @Query("SELECT * FROM daily_logs ORDER BY date DESC")
    fun getAllLogs(): Flow<List<DailyLogEntry>>

    @Query("SELECT * FROM daily_logs WHERE date = :date LIMIT 1")
    suspend fun getLogByDate(date: String): DailyLogEntry?

    @Query("SELECT * FROM daily_logs WHERE date = :date LIMIT 1")
    fun getLogByDateFlow(date: String): Flow<DailyLogEntry?>

    @Query("SELECT * FROM daily_logs ORDER BY date DESC LIMIT :limit")
    fun getRecentLogs(limit: Int): Flow<List<DailyLogEntry>>

    @Query("SELECT * FROM daily_logs ORDER BY date DESC LIMIT :limit")
    suspend fun getRecentLogsSync(limit: Int): List<DailyLogEntry>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(log: DailyLogEntry): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(logs: List<DailyLogEntry>)

    @Update
    suspend fun update(log: DailyLogEntry)

    @Query("DELETE FROM daily_logs WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT COUNT(DISTINCT date) FROM daily_logs")
    fun getTotalActiveDaysCount(): Flow<Int>
}
