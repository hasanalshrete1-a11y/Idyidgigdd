package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_logs")
data class DailyLogEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val date: String, // ISO date format: YYYY-MM-DD
    val income: Double = 0.0,
    val expense: Double = 0.0,
    val workHours: Double = 0.0,
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    val netProfit: Double
        get() = income - expense

    val effectiveHourlyRate: Double
        get() = if (workHours > 0.0) (income - expense) / workHours else 0.0
}
