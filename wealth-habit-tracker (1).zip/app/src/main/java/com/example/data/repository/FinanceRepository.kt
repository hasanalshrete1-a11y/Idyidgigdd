package com.example.data.repository

import com.example.data.local.dao.DailyLogDao
import com.example.data.local.entity.DailyLogEntry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class WeeklyFinancialSummary(
    val totalIncome: Double,
    val totalExpense: Double,
    val netSavings: Double,
    val totalHours: Double,
    val avgHourlyRate: Double,
    val isGrowing: Boolean, // true if netSavings > 0 and income > expenses
    val savingsRatePercentage: Double,
    val dailyPoints: List<DailyChartPoint>
)

data class DailyChartPoint(
    val dayLabel: String, // e.g., "Mon", "Tue"
    val date: String,
    val income: Double,
    val expense: Double,
    val net: Double,
    val workHours: Double
)

class FinanceRepository(private val dailyLogDao: DailyLogDao) {

    val allLogs: Flow<List<DailyLogEntry>> = dailyLogDao.getAllLogs()

    fun getTodayLog(date: String): Flow<DailyLogEntry?> = dailyLogDao.getLogByDateFlow(date)

    suspend fun getTodayLogSync(date: String): DailyLogEntry? = dailyLogDao.getLogByDate(date)

    fun getRecentLogs(limit: Int = 7): Flow<List<DailyLogEntry>> = dailyLogDao.getRecentLogs(limit)

    suspend fun insertOrUpdate(entry: DailyLogEntry): Long = dailyLogDao.insertOrUpdate(entry)

    suspend fun insertAll(entries: List<DailyLogEntry>) = dailyLogDao.insertAll(entries)

    suspend fun delete(id: Long) = dailyLogDao.deleteById(id)

    /**
     * Calculates consecutive active logging days streak up to today or yesterday.
     */
    fun getLoggingStreakFlow(): Flow<Int> = allLogs.map { logs ->
        calculateStreak(logs)
    }

    /**
     * Calculates dynamic weekly progress comparing income vs expense for the last 7 days.
     */
    fun getWeeklySummaryFlow(): Flow<WeeklyFinancialSummary> = allLogs.map { logs ->
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val dayFormat = SimpleDateFormat("EEE", Locale.getDefault())
        val calendar = Calendar.getInstance()

        val last7DaysPoints = mutableListOf<DailyChartPoint>()
        var totalIncome = 0.0
        var totalExpense = 0.0
        var totalHours = 0.0

        // Create entries for the last 7 days (today down to 6 days ago) in chronological order
        for (i in 6 downTo 0) {
            val cal = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, -i)
            }
            val dateStr = dateFormat.format(cal.time)
            val dayStr = dayFormat.format(cal.time)

            val log = logs.find { it.date == dateStr }
            val inc = log?.income ?: 0.0
            val exp = log?.expense ?: 0.0
            val hrs = log?.workHours ?: 0.0

            totalIncome += inc
            totalExpense += exp
            totalHours += hrs

            last7DaysPoints.add(
                DailyChartPoint(
                    dayLabel = dayStr,
                    date = dateStr,
                    income = inc,
                    expense = exp,
                    net = inc - exp,
                    workHours = hrs
                )
            )
        }

        val netSavings = totalIncome - totalExpense
        val avgHourlyRate = if (totalHours > 0.0) netSavings / totalHours else 0.0
        val isGrowing = netSavings >= 0.0 && totalIncome > 0.0
        val savingsRatePercentage = if (totalIncome > 0.0) {
            ((netSavings / totalIncome) * 100).coerceIn(-100.0, 100.0)
        } else {
            if (totalExpense > 0.0) -100.0 else 0.0
        }

        WeeklyFinancialSummary(
            totalIncome = totalIncome,
            totalExpense = totalExpense,
            netSavings = netSavings,
            totalHours = totalHours,
            avgHourlyRate = avgHourlyRate,
            isGrowing = isGrowing,
            savingsRatePercentage = savingsRatePercentage,
            dailyPoints = last7DaysPoints
        )
    }

    private fun calculateStreak(logs: List<DailyLogEntry>): Int {
        if (logs.isEmpty()) return 0
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val loggedDates = logs.map { it.date }.toSet()

        val cal = Calendar.getInstance()
        val todayStr = dateFormat.format(cal.time)

        cal.add(Calendar.DAY_OF_YEAR, -1)
        val yesterdayStr = dateFormat.format(cal.time)

        // Streak can continue from today or yesterday
        val startCal = Calendar.getInstance()
        var streak = 0

        if (loggedDates.contains(todayStr)) {
            streak++
            startCal.add(Calendar.DAY_OF_YEAR, -1)
        } else if (loggedDates.contains(yesterdayStr)) {
            startCal.add(Calendar.DAY_OF_YEAR, -1)
        } else {
            return 0
        }

        while (true) {
            val checkDate = dateFormat.format(startCal.time)
            if (loggedDates.contains(checkDate)) {
                if (checkDate != todayStr) {
                    streak++
                }
                startCal.add(Calendar.DAY_OF_YEAR, -1)
            } else {
                break
            }
        }

        return streak
    }
}
