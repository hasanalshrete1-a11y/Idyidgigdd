package com.example.util

import android.content.Context
import android.content.res.Configuration
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import java.util.Locale

data class SupportedLanguage(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val isRtl: Boolean = false
)

object LocaleManager {
    val supportedLanguages = listOf(
        SupportedLanguage(code = "en", displayName = "English", nativeName = "English", isRtl = false),
        SupportedLanguage(code = "ar", displayName = "Arabic", nativeName = "العربية", isRtl = true),
        SupportedLanguage(code = "es", displayName = "Spanish", nativeName = "Español", isRtl = false),
        SupportedLanguage(code = "fr", displayName = "French", nativeName = "Français", isRtl = false)
    )

    fun getLanguageByCode(code: String): SupportedLanguage {
        return supportedLanguages.find { it.code == code } ?: supportedLanguages.first()
    }

    fun getLocalizedContext(baseContext: Context, languageCode: String): Context {
        val locale = Locale(languageCode)
        Locale.setDefault(locale)
        val configuration = Configuration(baseContext.resources.configuration)
        configuration.setLocale(locale)
        configuration.setLayoutDirection(locale)
        return baseContext.createConfigurationContext(configuration)
    }
}

/**
 * Composable wrapper that applies dynamic in-app locale and layout direction (including Arabic RTL).
 */
@Composable
fun ProvideAppLocale(
    languageCode: String,
    content: @Composable () -> Unit
) {
    val currentContext = LocalContext.current
    val localizedContext = remember(languageCode, currentContext) {
        LocaleManager.getLocalizedContext(currentContext, languageCode)
    }

    val isRtl = languageCode == "ar"
    val layoutDirection = if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

    val localizedConfiguration = remember(languageCode, localizedContext) {
        Configuration(localizedContext.resources.configuration).apply {
            val loc = Locale(languageCode)
            setLocale(loc)
            setLayoutDirection(loc)
        }
    }

    CompositionLocalProvider(
        LocalContext provides localizedContext,
        LocalLayoutDirection provides layoutDirection,
        LocalConfiguration provides localizedConfiguration
    ) {
        content()
    }
}
